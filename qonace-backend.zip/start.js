import fs from 'node:fs';
import path from 'node:path';

// Crash prevention: log unhandled errors instead of silent failure
process.on('uncaughtException', (err) => {
  console.error('[CRITICAL] Uncaught exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('[CRITICAL] Unhandled rejection at:', promise, 'reason:', reason);
});

// Restore native Linux Prisma engines and client unconditionally
try {
  const root = process.cwd();
  const bundleDir = path.join(root, '.prisma_bundle');
  const targetDir = path.join(root, 'node_modules', '.prisma');

  if (fs.existsSync(bundleDir)) {
    fs.mkdirSync(path.join(targetDir, 'client'), { recursive: true });
    fs.cpSync(bundleDir, targetDir, { recursive: true, force: true });
    console.log('[Prisma Failsafe] Restored native Linux engines into node_modules/.prisma');
  }
} catch (err) {
  console.warn('[Prisma Failsafe Warning]:', err);
}

// Start backend server
await import('./dist/index.js');
